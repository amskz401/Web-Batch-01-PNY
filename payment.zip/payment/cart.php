<?php 
session_start();

$_SESSION['cart'] = [];

$id = $_GET['id'];

if($id == 1) {
	$name = "Iphone X";
	$price = 399;
} elseif ($id == 2) {
	$name = "Iphone 11";
	$price = 499;
} else {
	$name = "Iphone 11 Pro";
	$price = 599;
}

$_SESSION['cart'][$id] = [
	"id" => $id,
	"name" => $name,
	"price" => $price,
	"quantity" => 1
];

header("location: index.php");

 ?>