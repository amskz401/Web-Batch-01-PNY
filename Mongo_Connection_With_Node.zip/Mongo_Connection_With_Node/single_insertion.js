const { MongoClient } = require('mongodb');

// Connection URL
const url = 'mongodb://localhost:27017';
const client = new MongoClient(url);

// Database Name
const dbName = 'mongotonode';

async function singleInsertion() {
    // Use connect method to connect to the server
    await client.connect();
    // console.log('Connected successfully to server');
    const db = client.db(dbName);
    await db.collection('inventory').insertOne({
        item: 'canvas',
        qty: 100,
        tags: ['cotton'],
        size: { h: 28, w: 35.5, uom: 'cm' }
    });    
    // console.log("record inserted");
    // the following code examples can be pasted here...
  
    return res;
  }

  singleInsertion()
  .then( res => {
    console.log(res);
  }  )
  .catch(console.error)
  .finally(() => client.close());