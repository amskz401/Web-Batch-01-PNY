const { MongoClient, ObjectId } = require('mongodb');

// Connection URL
const url = 'mongodb://localhost:27017';
const client = new MongoClient(url);

// Database Name
const dbName = 'mongotonode';

async function updateOne() {
    // Use connect method to connect to the server
    await client.connect();
    // console.log('Connected successfully to server');
    const db = client.db(dbName);
    let res = await db.collection('inventory').updateOne(
      {_id: new ObjectId('659aa98712eb4db60f7a0467')}, // condition
      {$set: {
        item: 'mat updated',
        qty: 0,
        "tags": ["gray", "black", "blue"],
 
      }} // data
  );    
    // console.log("record inserted");
    // the following code examples can be pasted here...
  
    return res;
  }

  updateOne()
  .then( res => {
    console.log(res);
  }  )
  .catch(console.error)
  .finally(() => client.close());