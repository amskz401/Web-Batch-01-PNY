const { MongoClient, ObjectId } = require('mongodb');

// Connection URL
const url = 'mongodb://localhost:27017';
const client = new MongoClient(url);

// Database Name
const dbName = 'mongotonode';

async function updateMany() {
    // Use connect method to connect to the server
    await client.connect();
    // console.log('Connected successfully to server');
    const db = client.db(dbName);
    let res = await db.collection('inventory').updateMany(
      {item: 'mousepad'}, // condition
      {$set: {
        qty: 0
      }} // data
  );    
    // console.log("record inserted");
    // the following code examples can be pasted here...
  
    return res;
  }

  updateMany()
  .then( res => {
    console.log(res);
  }  )
  .catch(console.error)
  .finally(() => client.close());